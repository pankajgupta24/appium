package androidTestCases;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;

public class RealDevice_SwipeSettingTest {
	
	
private AndroidDriver<WebElement> androidDriver;
	
	
	@BeforeClass
	public void appiumSetup() throws Exception {
		
		DesiredCapabilities mobileCap= new DesiredCapabilities();
		mobileCap.setCapability("platformName", "Android");
		mobileCap.setCapability("platformVersion", "9");
		mobileCap.setCapability("deviceName", "1a67cc62");
		
		mobileCap.setCapability("noreset", true);
		mobileCap.setCapability("appPackage", "com.android.settings");
		mobileCap.setCapability("appActivity", ".MiuiSettings");
		
		String sAppiumURL="http://localhost:4723/wd/hub";
		
		androidDriver= new AndroidDriver<WebElement>(new URL(sAppiumURL), mobileCap);
		androidDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@AfterClass
	public void appiumTearDown() throws Exception {
		androidDriver.quit();
		
	}
	
	@Test
	public void swipevalidation() throws Exception {
		Thread.sleep(5000);
		PointOption point1, point2;
		//WebElement point1=androidDriver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout[2]/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[5]/android.widget.RelativeLayout")).click();
		
		point1= PointOption.point(250,750 );
		point2= PointOption.point(250,50 );
		new TouchAction(androidDriver).press(point1).waitAction().moveTo(point2).release().perform();
		
		Thread.sleep(3000);
		
		
	}
	
}
