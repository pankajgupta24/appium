package androidTestCases;

import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.appium.java_client.android.AndroidDriver;


public class RealDevice_ChromeBrowserTest {
	
	
private AndroidDriver<WebElement> androidDriver;
	
	
	@BeforeClass
	public void appiumSetup() throws Exception {
		
		DesiredCapabilities mobileCap= new DesiredCapabilities();
		mobileCap.setCapability("platformName", "Android");
		mobileCap.setCapability("platformVersion", "9");
		mobileCap.setCapability("deviceName", "1a67cc62");
		
		//mobileCap.setCapability("noreset", true);
		//mobileCap.setCapability("appPackage", "com.android.chrome");
		//mobileCap.setCapability("appActivity", "com.google.android.apps.chrome.Main");
		mobileCap.setCapability("browserName", "Chrome");
	  //mobileCap.setCapability("chromeOptions", "--disable-cache");
		String sAppiumURL="http://localhost:4723/wd/hub";
		
		androidDriver= new AndroidDriver<WebElement>(new URL(sAppiumURL), mobileCap);
		androidDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@AfterClass
	public void appiumTearDown() throws Exception {
		androidDriver.quit();
		
	}
	
	@Test
	public void swipevalidation() throws Exception {
		
		androidDriver.get("http://www.apple.com/in/");
		
		
		androidDriver.context(androidDriver.getContextHandles().toArray()[0].toString());
		androidDriver.findElement(By.id("tab_switcher_button")).click();
		Thread.sleep(3000);
		
		androidDriver.findElement(By.id("new_tab_button")).click();
		Thread.sleep(3000);
		androidDriver.get("https://www.facebook.com");
		
		int i,count;
		count= androidDriver.getContextHandles().size();
		for (i=0;i<count;i++) {
			System.out.printf("Context %d of %d=%s\n", i+1,count,androidDriver.getContextHandles().toArray()[i].toString() );
			
		}
		
		
		
	
		
		
		
		for (i=0;i<count;i++) {
			String sContext= androidDriver.getContextHandles().toArray()[i].toString();
			androidDriver.context(sContext);
			try {
				System.out.println("\nSwticking to " + sContext);
				System.out.println(androidDriver.getCurrentUrl());
				System.out.println("-Passed--");
			}
			catch(Exception e) {
				System.out.println("----Failed---");
			}
		}
		
		
		Thread.sleep(5000);
		System.out.println(androidDriver.getContextHandles().size());
		System.out.println(androidDriver.getContext());
		Thread.sleep(3000);
		
		System.out.println(androidDriver.getTitle());
		}
	
}
