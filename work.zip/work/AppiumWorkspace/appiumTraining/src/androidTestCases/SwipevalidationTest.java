package androidTestCases;

import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class SwipevalidationTest {
private AndroidDriver<WebElement> androidDriver;
	
	
	@BeforeClass
	public void appiumSetup() throws Exception {
		
		DesiredCapabilities mobileCap= new DesiredCapabilities();
		mobileCap.setCapability("platformName", "Android");
		mobileCap.setCapability("platformVersion", "9");
		mobileCap.setCapability("deviceName", "1a67cc62");
		
		mobileCap.setCapability("noreset", true);
		mobileCap.setCapability("appPackage", "com.miui.gallery");
		mobileCap.setCapability("appActivity", ".activity.HomePageActivity");
		
		String sAppiumURL="http://localhost:4723/wd/hub";
		
		androidDriver= new AndroidDriver<WebElement>(new URL(sAppiumURL), mobileCap);
		androidDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@AfterClass
	public void appiumTearDown() throws Exception {
		androidDriver.quit();
		
	}
	
	@Test
	public void swipevalidation() throws Exception {
		Thread.sleep(5000);
		
		
		PointOption point1, point2, point3, point4, point5,point6,point7;
		
		TouchAction action = new TouchAction(androidDriver);
		
		point3= PointOption.point(124, 513);
		
		action.tap(point3).perform().tap(point3).perform();
		Thread.sleep(2000);
		


    androidDriver.pressKey(new KeyEvent().withKey(AndroidKey.TAB));
    androidDriver.pressKey(new KeyEvent().withKey(AndroidKey.A));
    androidDriver.pressKey(new KeyEvent().withKey(AndroidKey.D));
    androidDriver.pressKey(new KeyEvent().withKey(AndroidKey.M));
    androidDriver.pressKey(new KeyEvent().withKey(AndroidKey.I));
    androidDriver.pressKey(new KeyEvent().withKey(AndroidKey.N));
    Thread.sleep(2000); 
    
    
    
    
    

        
    MultiTouchAction multiAction = new MultiTouchAction( androidDriver);
    AndroidTouchAction finger1, finger2;
    
    
    point1 = PointOption.point(350, 500);
    point2 = PointOption.point(300, 500);
    finger1 = new AndroidTouchAction(androidDriver).press(point1)
                     .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
                     .moveTo(point2)
                     .release();
    
    point3 = PointOption.point(350, 550);
    point4 = PointOption.point(450, 550);
    finger2 = new AndroidTouchAction(androidDriver).press(point3)
//          .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
            .moveTo(point4)
            .release();

    multiAction.add(finger1);
    multiAction.add(finger2);
    multiAction.perform();
    
    Thread.sleep(2000);
    
    point1 = PointOption.point(300, 500);
    point2 = PointOption.point(350, 500);
    finger1 = new AndroidTouchAction(androidDriver).press(point1)
                     .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
                     .moveTo(point2)
                     .release();
    
    point3 = PointOption.point(450, 550);
    point4 = PointOption.point(400, 550);
    finger2 = new AndroidTouchAction(androidDriver).press(point3)
//          .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
            .moveTo(point4)
            .release();

    multiAction.add(finger1);
    multiAction.add(finger2);
    multiAction.perform();      
    
    
    
    Thread.sleep(2000);
       

}}
