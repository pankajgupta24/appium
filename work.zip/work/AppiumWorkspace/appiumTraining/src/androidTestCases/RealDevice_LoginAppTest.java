package androidTestCases;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class RealDevice_LoginAppTest {
	
	
private AndroidDriver<WebElement> androidDriver;
	
	
	@BeforeClass
	public void appiumSetup() throws Exception {
		
		DesiredCapabilities mobileCap= new DesiredCapabilities();
		mobileCap.setCapability("platformName", "Android");
		//mobileCap.setCapability("platformVersion", "9");
		//mobileCap.setCapability("deviceName", "1a67cc62");
		mobileCap.setCapability("platformVersion", "9");
		mobileCap.setCapability("deviceName", "emulator-5554");
		mobileCap.setCapability("noreset", true);
		mobileCap.setCapability("appPackage", "com.chikkanna.tgcloginapp");
		mobileCap.setCapability("appActivity", ".LoginActivity");
		
		String sAppiumURL="http://localhost:4723/wd/hub";
		
		androidDriver= new AndroidDriver<WebElement>(new URL(sAppiumURL), mobileCap);
		androidDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@AfterClass
	public void appiumTearDown() throws Exception {
		androidDriver.quit();
		
	}
	
	@Test
	public void loginvalidation() throws Exception {
		Thread.sleep(5000);
		MobileElement userField , passField;
		userField= (MobileElement) androidDriver.findElement(By.id("usernameField"));
		userField.sendKeys(userField.getText().split("'")[1]);
		
		passField= (MobileElement) androidDriver.findElement(By.id("passwordField"));
		passField.sendKeys(passField.getText().split("'")[1]);
		
		androidDriver.findElement(By.id("loginBtn")).click();
		
		Thread.sleep(3000);
		
		String msg= androidDriver.findElement(By.id("successMsg")).getText();
		Assert.assertEquals(msg, "Welcome, You've successfully logged in.");
		
		androidDriver.findElement(By.id("logoutBtn")).click();
		Thread.sleep(3000);
		
		androidDriver.findElement(By.id("android:id/button1")).click();
		Thread.sleep(3000);
		
		String loginMsg= androidDriver.findElement(By.id("authName")).getText();
		Assert.assertEquals(loginMsg, "Login TestApp : By Chikkanna T G");
		Thread.sleep(2000);
		
		
		
		
	}
	
}
