package androidTestCases;

import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.appium.java_client.MobileBy.ByAccessibilityId;
import io.appium.java_client.android.AndroidDriver;

public class RealDevice_CalCTest {
	
	private AndroidDriver<WebElement> androidDriver;
	
	
	@BeforeClass
	public void appiumSetup() throws Exception {
		
		DesiredCapabilities mobileCap= new DesiredCapabilities();
		mobileCap.setCapability("platformName", "Android");
		mobileCap.setCapability("platformVersion", "9");
		mobileCap.setCapability("deviceName", "emulator-5554");
		mobileCap.setCapability("noreset", true);
		mobileCap.setCapability("appPackage", "com.android.calculator2");
		mobileCap.setCapability("appActivity", ".Calculator");
		
		String sAppiumURL="http://localhost:4723/wd/hub";
		
		androidDriver= new AndroidDriver<WebElement>(new URL(sAppiumURL), mobileCap);

	}

	@AfterClass
	public void appiumTearDown() throws Exception {
		androidDriver.quit();
		
	}
	
	@Test
	public void calCValidation() throws Exception {
		Thread.sleep(5000);
		androidDriver.findElement(By.id("digit_7")).click();
		androidDriver.findElement(By.id("digit_2")).click();
		androidDriver.findElement(By.id("digit_3")).click();
		androidDriver.findElement(By.id("digit_4")).click();
		androidDriver.findElementByAccessibilityId("plus").click();
		Thread.sleep(5000);
		androidDriver.findElement(By.id("digit_5")).click();
		androidDriver.findElement(By.id("digit_9")).click();
		androidDriver.findElement(By.id("digit_6")).click();
		androidDriver.findElementByAccessibilityId("equals").click();
		Thread.sleep(3000);
		//androidDriver.findElementByAccessibilityId("equals").click();
		String result= androidDriver.findElement(By.id("result")).getText();
		System.out.println(result);
		Assert.assertEquals("7,830", result);
	
	}
	
}
