package androidTestCases;

import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class RealDevice_GalleryZoonInOutTest {
	
	
private AndroidDriver<WebElement> androidDriver;
	
	
	@BeforeClass
	public void appiumSetup() throws Exception {
		
		DesiredCapabilities mobileCap= new DesiredCapabilities();
		mobileCap.setCapability("platformName", "Android");
		mobileCap.setCapability("platformVersion", "9");
		mobileCap.setCapability("deviceName", "1a67cc62");
		
		mobileCap.setCapability("noreset", true);
		mobileCap.setCapability("appPackage", "com.miui.gallery");
		mobileCap.setCapability("appActivity", ".activity.HomePageActivity");
		
		String sAppiumURL="http://localhost:4723/wd/hub";
		
		androidDriver= new AndroidDriver<WebElement>(new URL(sAppiumURL), mobileCap);
		androidDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@AfterClass
	public void appiumTearDown() throws Exception {
		androidDriver.quit();
		
	}
	
	@Test
	public void swipevalidation() throws Exception {
		Thread.sleep(5000);
		
		
		PointOption point1, point2, point3, point4, point5,point6,point7;
		
		TouchAction action = new TouchAction(androidDriver);
		
		point3= PointOption.point(124, 513);
		
		action.tap(point3).perform().tap(point3).perform();
		Thread.sleep(2000);
		
		MultiTouchAction multiTouch= new MultiTouchAction(androidDriver);
		TouchAction finger1, finger2;
		
		point4= PointOption.point(348,1158);
		point5= PointOption.point(348,600);
		action.tap(point4).perform().tap(point4).perform();

		finger1= action.press(point4).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2))).moveTo(point5).release();
		Thread.sleep(2000);
		
		point6= PointOption.point(348,1300);
		point7= PointOption.point(348,400);
		
		finger2= action.press(point6).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2))).moveTo(point7).release();
				
		multiTouch.add(finger1);
		multiTouch.add(finger2);
		Thread.sleep(4000);
		multiTouch.perform();
		
		
		Thread.sleep(3000);
		
		
	}
	
}
