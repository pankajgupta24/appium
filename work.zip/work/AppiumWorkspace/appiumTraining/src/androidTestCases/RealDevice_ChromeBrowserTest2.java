
package androidTestCases;

import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class RealDevice_ChromeBrowserTest2 
{
    //private AndroidDriver<WebElement> androidDriver;
    private AppiumDriver<WebElement> androidDriver;
    
    
    //-------------------------------------------------------------
    
    @BeforeClass
    public void appiumSetup() throws Exception
    {
        DesiredCapabilities mobileCap = new DesiredCapabilities();
        mobileCap.setCapability("platformName", "Android");
        mobileCap.setCapability("platformVersion", "9");
        mobileCap.setCapability("deviceName", "1a67cc62");
        mobileCap.setCapability("browserName", "chrome");


        String sAppiumUrl = "http://localhost:4723/wd/hub";
        
        androidDriver = new AppiumDriver<WebElement>(new URL(sAppiumUrl), mobileCap);
        androidDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        

    }
    
    //-------------------------------------------------------------
    @AfterClass
    public void appiumTeardown() throws Exception
    {
        androidDriver.quit();
    }
    
    
    //-------------------------------------------------------------
    
    @Test
    public void webValidation() throws Exception
    {

        androidDriver.get("http://www.seleniumhq.org");
        Thread.sleep(2000);
        
        PointOption point1, point2;
        
        point1 = PointOption.point(250, 150);
        point2 = PointOption.point(250, 850);
        
        new TouchAction(androidDriver).press(point1)
                    .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
                    .moveTo(point2).release().perform();
        Thread.sleep(2000);     
//      System.out.println(androidDriver.getWindowHandles().size());
        
        
        androidDriver.context(androidDriver.getContextHandles().toArray()[0].toString());
        
        androidDriver.findElementById("tab_switcher_button").click();
        Thread.sleep(2000);
        androidDriver.findElementById("new_tab_button").click();
        Thread.sleep(2000);
        
        
        
        int i, count;
        
        count = androidDriver.getContextHandles().size();
        
        for(i=0; i<count; i++)
            System.out.printf("Context %d of %d = %s\n", i+1, count, 
                    androidDriver.getContextHandles().toArray()[i].toString());
        
        
    
        androidDriver.context(androidDriver.getContextHandles().toArray()[1].toString());
        androidDriver.switchTo().window(androidDriver.getWindowHandles().toArray()[1].toString());
        androidDriver.get("http://www.bing.com");
        System.out.println("sent url to second tab...");
        Thread.sleep(3000);
        //System.out.println(androidDriver.getWindowHandles().size());
        androidDriver.close();
        androidDriver.context(androidDriver.getContextHandles().toArray()[0].toString());
        Thread.sleep(3000);
        

    }

    
    //-------------------------------------------------------------
    
    
    //-------------------------------------------------------------
    
    
    
    
}



