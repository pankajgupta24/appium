package IOS;

import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.appium.java_client.MobileBy.ByAccessibilityId;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class AIOSSimulatortest1 {
	
	private IOSDriver<IOSElement> iosDriver;
	
	
	@BeforeClass
	public void appiumSetup() throws Exception {
		
		DesiredCapabilities mobileCap= new DesiredCapabilities();
		mobileCap.setCapability("platformName", "iOS");
		mobileCap.setCapability("platformVersion", "13.2");
		mobileCap.setCapability("deviceName", "iPhone 11 Pro Max");
		mobileCap.setCapability("noreset", true);
		mobileCap.setCapability("bundleId", "com.apple.MobileAddressBook");
		mobileCap.setCapability("automationName", "XCUITest");
		
		String sAppiumURL="http://localhost:4723/wd/hub";
		
		iosDriver= new IOSDriver<IOSElement>(new URL(sAppiumURL), mobileCap);

	}

	@AfterClass
	public void appiumTearDown() throws Exception {
		iosDriver.quit();
		
	}
	
	@Test
	public void addressbookvalidation() throws Exception {
		Thread.sleep(5000);
		iosDriver.findElementByAccessibilityId("Kate Bell").click();
		Thread.sleep(5000);
		IOSElement obj= iosDriver.findElementByAccessibilityId("mobile");
		System.out.println(obj.getText());
		iosDriver.navigate().back();
		Thread.sleep(3000);
	}
	
}
