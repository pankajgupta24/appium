package IOS;

import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.appium.java_client.MobileBy.ByAccessibilityId;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class AIOSSimulatortest2 {
	
	private IOSDriver<IOSElement> iosDriver;
	
	
	@BeforeClass
	public void appiumSetup() throws Exception {
		
		DesiredCapabilities mobileCap= new DesiredCapabilities();
		mobileCap.setCapability("platformName", "iOS");
		mobileCap.setCapability("platformVersion", "13.2");
		mobileCap.setCapability("deviceName", "iPhone 11 Pro Max");
		mobileCap.setCapability("noreset", true);
		mobileCap.setCapability("bundleId", "com.apple.MobileAddressBook");
		mobileCap.setCapability("automationName", "XCUITest");
		
		String sAppiumURL="http://localhost:4723/wd/hub";
		
		iosDriver= new IOSDriver<IOSElement>(new URL(sAppiumURL), mobileCap);

	}

	@AfterClass
	public void appiumTearDown() throws Exception {
		iosDriver.quit();
		
	}
	
	@Test
	public void addressbookvalidation() throws Exception {
		Thread.sleep(5000);
		
		int i, count;
		List<IOSElement> allItems;
		IOSElement indivItems;
		System.out.println(iosDriver.findElementsByClassName("XCUIElementTypeStaticText").size());
		allItems= iosDriver.findElementsByClassName("XCUIElementTypeStaticText");
		count= allItems.size();
		
		String mobileNum;
		for (i=2;i <count; i ++) {
			
			indivItems= allItems.get(i);
			System.out.printf("%d of %d = %s\n", i-1, count-2, indivItems.getText());
			indivItems.click();
			
			IOSElement numElement= iosDriver.
					findElementByXPath("//XCUIElementTypeCell[@name='mobile' or @name= 'work' or @name='home']");
			
			mobileNum= numElement.getText();
			
			
			System.out.printf("\t%s=%s\n\n", numElement.getAttribute("name"), mobileNum);
			
			iosDriver.navigate().back();
			
		}
		
		Thread.sleep(3000);
	}
	
}
